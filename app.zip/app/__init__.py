"""
Application entry point module.
Ensures __init__.py exists for proper package structure.
"""
